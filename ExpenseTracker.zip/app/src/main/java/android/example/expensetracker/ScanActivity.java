package android.example.expensetracker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.service.autofill.RegexValidator;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScanActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    ImageView mPreviewIv;
    TextView mResultEt;
    Uri resulturi;
    private Object ArrayList;
    Spinner spinner;
    Button buttonSave;
    DatabaseReference databaseExpenseTracker;
    FirebaseAuth mAuth;
    String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
            "October", "November", "December"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        mAuth = FirebaseAuth.getInstance();

        Calendar cal = Calendar.getInstance();
        String month = monthName[cal.get(Calendar.MONTH)];
        databaseExpenseTracker = FirebaseDatabase.getInstance().getReference(month).child(mAuth.getCurrentUser().getUid());

        mPreviewIv = findViewById(R.id.imageIv);
        mResultEt = findViewById(R.id.resultEt);
        buttonSave = findViewById(R.id.button_save);
        spinner = findViewById(R.id.spinner_item);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null && bundle.containsKey("KEY")){
            resulturi = Uri.parse(bundle.getString("KEY"));
            mPreviewIv.setImageURI(resulturi);
        }

        //get drawable bitmap for text recognition
        BitmapDrawable bitmapDrawable = (BitmapDrawable)mPreviewIv.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        TextRecognizer recognizer = new TextRecognizer.Builder(getApplicationContext()).build();

        if(!recognizer.isOperational()){
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
        else {
            Frame frame = new Frame.Builder().setBitmap(bitmap).build();
            SparseArray<TextBlock> items = recognizer.detect(frame);
            StringBuilder sb = new StringBuilder();

            //get text from sb until there is no text

            for (int i = 0; i < items.size(); i++) {
                TextBlock myItem = items.valueAt(i);
                Pattern p = Pattern.compile("[+-]?([0-9]*[,])?[0-9]+");
                Matcher m = p.matcher(myItem.getValue());
                while(m.find()){
                    if(m.group().contains(",")&&!m.group().contains("-")){
                           sb.append(m.group());
                           sb.append("\n");
                        }
                }
            }
            String text = sb.toString();
            text = text.replaceAll(",",".");
            String[] newPrices = text.split("\n");
            Double[] values = new Double[newPrices.length];
                for(int i =0;i<newPrices.length;i++){
                    values[i]=Double.parseDouble(newPrices[i]);
                }
                double maxNumber = Collections.max(Arrays.asList(values));

            mResultEt.setText(Double.toString(maxNumber));
        }
            buttonSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveResult();
                }
            });
    }

    private void saveResult() {
        String mResult = mResultEt.getText().toString();
        String itemId = spinner.getSelectedItem().toString();
        DateFormat df = new SimpleDateFormat("yyyyMMdd - hh:mm:ss");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        if(!mAuth.getCurrentUser().getUid().isEmpty()) {
            if (!TextUtils.isEmpty(mResult)) {
                ExpenseTracker expensetracker = new ExpenseTracker(itemId, mResult, date);
                databaseExpenseTracker.child(itemId).child(date).setValue(expensetracker);
                Toast.makeText(ScanActivity.this, "Result added", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(ScanActivity.this, "You should choose the value", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(this, "You should login first", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String spinnerLabel = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

}




