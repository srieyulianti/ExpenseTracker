package android.example.expensetracker;

public class ExpenseTracker {
    String itemId;
    String result;
    String date;

    public ExpenseTracker(){

    }

    public ExpenseTracker(String itemId, String result, String date) {
        this.itemId = itemId;
        this.result = result;
        this.date = date;
    }


    public String getItemId() {
        return itemId;
    }

    public String getResult() {
        return result;
    }

    public String getDate() {
        return date;
    }
}
