package android.example.expensetracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ActiveProfile extends AppCompatActivity {
    TextView textView;
    ImageView imageView;
    TextView textView1;
    Uri uriProfileImage;
    FirebaseAuth mAuth;
    Button update;
    Button logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_profile);
        mAuth = FirebaseAuth.getInstance();
        textView1 = findViewById(R.id.username);
        imageView = findViewById(R.id.profile_picture);
        textView = findViewById(R.id.textviewVerified);
        loadUserInformation();
        update = findViewById(R.id.buttonUpdate);
        logout = findViewById(R.id.buttonLogout);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserProfile();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutFromApp();
            }
        });

    }

    private void logoutFromApp() {
        FirebaseAuth.getInstance().signOut();
        finish();
        startActivity(new Intent(this, LoginActivity.class));
    }

    private void updateUserProfile() {
        Intent intent = new Intent(ActiveProfile.this, ProfileActivity.class);
        startActivity(intent);
    }

    private void loadUserInformation() {
        final FirebaseUser user = mAuth.getCurrentUser();
        if(user!=null) {
            if (user.getPhotoUrl() != null) {
                Glide.with(ActiveProfile.this).load(user.getPhotoUrl().toString()).into(imageView);
            }
            if (user.getDisplayName() != null) {
                textView1.setText(user.getDisplayName());
            }
            if(user.isEmailVerified()){
                textView.setText("Email Verified");
            }else{
                textView.setText("Email Not Verified (Click to Verify)");
                textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(ActiveProfile.this, "Verification Email Sent", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
        }
    }
}
