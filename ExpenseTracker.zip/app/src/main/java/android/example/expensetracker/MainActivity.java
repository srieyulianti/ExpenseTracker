package android.example.expensetracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.Text;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST_CODE = 200;
    private static final int IMAGE_PICK_CAMERA_CODE = 1001;
    String cameraPermission[];
    Uri image_uri;
    TextView totalincome;
    TextView incomeInput;
    TextView remainingincome;
    TextView currentMonth;
    FirebaseAuth mAuth;
    TextView Groceries;
    TextView Clothes;
    TextView Electronic;
    TextView Housing;
    TextView Leisure;
    TextView Traveling;
    TextView Transport;
    TextView Book;
    TextView Games;
    TextView Health;
    TextView Restaurant;
    TextView Others;
    TextView totalexpense;
    String totalClothesExpense;
    String totalGroceriesExpense;
    String totalBookExpense;
    String totalElectronicExpense;
    String totalGamesExpense;
    String totalHealthExpense;
    String totalHousingExpense;
    String totalLeisureExpense;
    String totalOthersExpense;
    String totalRestaurantExpense;
    String totalTransportExpense;
    String totalTravelingExpense;
    String totalIncomeInput;
    String totalExpenseInput;
    ImageView groceryImage;
    ImageView clothImage;
    ImageView bookImage;
    ImageView electronicImage;
    ImageView gameImage;
    ImageView healthImage;
    ImageView housingImage;
    ImageView leisureImage;
    ImageView otherImage;
    ImageView restaurantImage;
    ImageView transportImage;
    ImageView travelingImage;
    DatabaseReference databaseExpenseTracker;
    String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
            "October", "November", "December"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mAuth = FirebaseAuth.getInstance();

        Calendar cal = Calendar.getInstance();
        String month = monthName[cal.get(Calendar.MONTH)];
        databaseExpenseTracker = FirebaseDatabase.getInstance().getReference(month).child(mAuth.getCurrentUser().getUid());

        totalincome = (TextView) findViewById(R.id.total_income);
        Groceries = (TextView) findViewById(R.id.groceries_expense);
        Transport = (TextView) findViewById(R.id.transport_expense);
        Clothes = (TextView) findViewById(R.id.clothes_expense);
        Book = (TextView) findViewById(R.id.book_expense);
        Electronic = (TextView) findViewById(R.id.electronic_expense);
        Games = (TextView) findViewById(R.id.games_expense);
        Housing = (TextView) findViewById(R.id.housing_expense);
        Health = (TextView) findViewById(R.id.health_expense);
        Leisure = (TextView) findViewById(R.id.leisure_expense);
        Restaurant = (TextView) findViewById(R.id.restaurant_expense);
        Traveling = (TextView) findViewById(R.id.traveling_expense);
        Others = (TextView) findViewById(R.id.others_expense);
        totalexpense = (TextView) findViewById(R.id.expense);
        groceryImage = (ImageView) findViewById(R.id.groceries_item);
        clothImage = (ImageView) findViewById(R.id.clothes_item);
        bookImage = (ImageView) findViewById(R.id.education_item);
        electronicImage = (ImageView) findViewById(R.id.electronic_item);
        gameImage = (ImageView) findViewById(R.id.games_item);
        healthImage = (ImageView) findViewById(R.id.health_item);
        housingImage = (ImageView) findViewById(R.id.housing_item);
        leisureImage = (ImageView) findViewById(R.id.leisure_item);
        otherImage = (ImageView) findViewById(R.id.others_item);
        restaurantImage = (ImageView) findViewById(R.id.restaurant_item);
        transportImage = (ImageView) findViewById(R.id.transport_item);
        travelingImage = (ImageView) findViewById(R.id.traveling_item);
        incomeInput = (TextView) findViewById(R.id.income);
        remainingincome = (TextView) findViewById(R.id.remaining);
        currentMonth = (TextView) findViewById(R.id.current_month);

        groceryImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                groceryDetail();
            }
        });
        clothImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clothDetail();
            }
        });
        bookImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookDetail();
            }
        });
        electronicImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                electronicDetail();
            }
        });
        gameImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameDetail();
            }
        });
        healthImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                healthDetail();
            }
        });
        housingImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                housingDetail();
            }
        });
        leisureImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leisureDetail();
            }
        });
        otherImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otherDetail();
            }
        });
        restaurantImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restaurantDetail();
            }
        });
        transportImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transportDetail();
            }
        });
        travelingImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                travelingDetail();
            }
        });


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scanBillInformation();
            }
        });

        FloatingActionButton fab2 = findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ManualInputActivity.class);
                startActivity(intent);
            }
        });

        Formatter df = new Formatter();
        df = new Formatter();
        df.format("%tB", cal);
        currentMonth.setText(df.toString());

        totalincome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.update_income, null);
                dialogBuilder.setView(dialogView);
                final EditText editTextName = (EditText) dialogView.findViewById(R.id.edit_income);
                final Button alertSave = (Button) dialogView.findViewById(R.id.button_save);
                final Button alertCancel = (Button) dialogView.findViewById(R.id.button_cancel);
                alertSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String mIncome = editTextName.getText().toString();
                        String itemId = "Income";
                        DateFormat df = new SimpleDateFormat("yyyyMMdd - hh:mm:ss");
                        Date dateobj = new Date();
                        String date = df.format(dateobj);
                            if (!TextUtils.isEmpty(mIncome)) {
                                ExpenseTracker expensetracker = new ExpenseTracker(itemId, mIncome, date);
                                databaseExpenseTracker.child(itemId).child(date).setValue(expensetracker);
                                Toast.makeText(MainActivity.this, "Income added", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this, "You should choose the value or item category", Toast.LENGTH_LONG).show();
                            }
                    }
                });
                alertCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                });
                dialogBuilder.show();
            }
        });

        //camera permission
        cameraPermission = new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};


        databaseExpenseTracker.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                double totalAmount0 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Clothes").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount0 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalClothesExpense = Double.toString(totalAmount0);
                    Clothes.setText(totalClothesExpense);
                    Double clothesExpense = totalAmount0;

                double totalAmount1 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Groceries").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount1 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalGroceriesExpense = Double.toString(totalAmount1);
                    Groceries.setText(totalGroceriesExpense);
                    Double groceriesExpense = totalAmount1;

                double totalAmount2 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Book").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount2 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalBookExpense = Double.toString(totalAmount2);
                    Book.setText(totalBookExpense);
                    Double bookExpense = totalAmount2;

                double totalAmount3 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Electronic").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount3 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalElectronicExpense = Double.toString(totalAmount3);
                    Electronic.setText(totalElectronicExpense);
                    Double electronicExpense = totalAmount3;

                double totalAmount4 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Games").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount4 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalGamesExpense = Double.toString(totalAmount4);
                    Games.setText(totalGamesExpense);
                    Double gamesExpense = totalAmount4;

                double totalAmount5 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Health").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount5 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalHealthExpense = Double.toString(totalAmount5);
                    Health.setText(totalHealthExpense);
                    Double healthExpense = totalAmount5;

                double totalAmount6 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Housing").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount6 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalHousingExpense = Double.toString(totalAmount6);
                    Housing.setText(totalHousingExpense);
                    Double housingExpense = totalAmount6;

                double totalAmount7 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Leisure").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount7 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalLeisureExpense = Double.toString(totalAmount7);
                    Leisure.setText(totalLeisureExpense);
                    Double leisureExpense = totalAmount7;

                double totalAmount8 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Others").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount8 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalOthersExpense = Double.toString(totalAmount8);
                    Others.setText(totalOthersExpense);
                    Double otherExpense = totalAmount8;

                double totalAmount9 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Restaurant").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount9 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalRestaurantExpense = Double.toString(totalAmount9);
                    Restaurant.setText(totalRestaurantExpense);
                    Double restaurantExpense = totalAmount9;

                double totalAmount10 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Transport").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount10 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalTransportExpense = Double.toString(totalAmount10);
                    Transport.setText(totalTransportExpense);
                    Double transportExpense = totalAmount10;

                double totalAmount11 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Traveling").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount11 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalTravelingExpense = Double.toString(totalAmount11);
                    Traveling.setText(totalTravelingExpense);
                    Double travelingExpense = totalAmount11;

                    Double totalExpense = clothesExpense + groceriesExpense + bookExpense + electronicExpense +
                            gamesExpense + healthExpense + housingExpense + leisureExpense + otherExpense +
                            restaurantExpense + transportExpense + travelingExpense;
                    totalExpenseInput = Double.toString(totalExpense);
                    String ExpenseInput = String.format("%.2f", totalExpense);
                    totalexpense.setText(ExpenseInput);

                double totalAmount12 = 0;
                for(DataSnapshot postSnapshot : dataSnapshot.child("Income").getChildren()){
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount12 += Double.parseDouble(gettotalamount.getResult());
                }
                    totalIncomeInput = Double.toString(totalAmount12);
                    incomeInput.setText(totalIncomeInput);
                    Double totalIncome = totalAmount12;

                    Double remainingIncome = totalIncome - totalExpense;
                    String remaining = Double.toString(remainingIncome);
                    if(totalIncome < totalExpense){
                        remainingincome.setText("0.0");
                    }else{
                        remainingincome.setText(remaining);
                    }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "The read failed", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void travelingDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Traveling.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void transportDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Transport.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void restaurantDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Restaurant.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void otherDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Others.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void leisureDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Leisure.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void housingDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Housing.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void healthDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Health.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void gameDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Games.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void electronicDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Electronic.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void bookDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Book.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void clothDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Clothes.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void groceryDetail() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.item_detail, null);
        dialogBuilder.setView(dialogView);
        final TextView totalAmount = (TextView) dialogView.findViewById(R.id.total);
        final TextView currentDate = (TextView) dialogView.findViewById(R.id.date);
        totalAmount.setText(Groceries.getText().toString());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        currentDate.setText(date);
        dialogBuilder.show();
    }

    private void scanBillInformation() {
        if(!checkCameraPermission()){
            requestCameraPermission();
        }else{
            pickCamera();
        }

    }

    private void pickCamera() {
        //intent to take image from camera, it will also be saved to storage to get high quality image
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "NewPic"); //title of the picture
        values.put(MediaStore.Images.Media.DESCRIPTION, "Image To text");// description
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(cameraIntent, IMAGE_PICK_CAMERA_CODE);
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, cameraPermission, CAMERA_REQUEST_CODE);
    }

    private boolean checkCameraPermission() {
        /*Check camera permission and return the result
         *In order to get high quality image we have to save image to external storage first
         * before inserting to image view that's why storage permission will also be required*/
        boolean result = ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA) == (PackageManager.PERMISSION_GRANTED);
        boolean resultl = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result && resultl;
    }

    //handle permission result


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case CAMERA_REQUEST_CODE:
                if(grantResults.length>0){
                    boolean cameraAccepted = grantResults[0] ==
                            PackageManager.PERMISSION_GRANTED;
                    boolean writeStorageAccepted = grantResults[0] ==
                            PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && writeStorageAccepted){
                        pickCamera();
                    }else{
                        Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
    }

    //handle image result
    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_CAMERA_CODE) {
                //got image from camera now crop it
                CropImage.activity(image_uri)
                        .setGuidelines(CropImageView.Guidelines.ON) //enable image guidelines
                        .start(this);
            }
        }
        //get cropped image
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri(); //get image uri
                //set image to image view
                Intent intent = new Intent(this, ScanActivity.class);
                intent.putExtra("KEY",resultUri.toString());
                startActivity(intent);
            }
            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                //if there is any error show it
                Exception error = result.getError();
                Toast.makeText(this, ""+error, Toast.LENGTH_SHORT).show();

            }
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_account:
                Intent intent = new Intent(MainActivity.this, ActiveProfile.class);
                startActivity(intent);
                return true;
            case R.id.action_chart:
                Intent intent2 = new Intent(MainActivity.this, PieChartActivity.class);
                startActivity(intent2);
                return true;
            case R.id.action_notification:
                Intent intent3 = new Intent(MainActivity.this, NotificationActivity.class);
                startActivity(intent3);
                return true;
            case R.id.action_settings:
                Intent intent4 = new Intent(MainActivity.this, AboutUsActivity.class);
                startActivity(intent4);
                return true;
            default:
                // Do nothing
        }
        return super.onOptionsItemSelected(item);
    }
    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }
}
