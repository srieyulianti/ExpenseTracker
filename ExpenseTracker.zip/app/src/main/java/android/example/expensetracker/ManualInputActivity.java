package android.example.expensetracker;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ManualInputActivity extends AppCompatActivity {

    EditText editTextName;
    ImageView Groceries;
    ImageView Clothes;
    ImageView Electronic;
    ImageView Housing;
    ImageView Leisure;
    ImageView Traveling;
    ImageView Transport;
    ImageView Book;
    ImageView Games;
    ImageView Health;
    ImageView Restaurant;
    ImageView Others;
    String itemId;
    Button saveItem;
    FirebaseAuth mAuth;
    DatabaseReference databaseExpenseTracker;
    String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
    "October", "November", "December"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_input);
        editTextName = (EditText) findViewById(R.id.edittext_amt);
        Groceries = (ImageView) findViewById(R.id.Grocery);
        Clothes = (ImageView) findViewById(R.id.cloths);
        Electronic = (ImageView) findViewById(R.id.Electronics);
        Housing = (ImageView) findViewById(R.id.housing);
        Leisure = (ImageView) findViewById(R.id.leisure);
        Traveling = (ImageView) findViewById(R.id.travel);
        Transport = (ImageView) findViewById(R.id.transport);
        Book = (ImageView) findViewById(R.id.Education);
        Games = (ImageView) findViewById(R.id.Gaming);
        Health = (ImageView) findViewById(R.id.health);
        Restaurant = (ImageView) findViewById(R.id.restaurent);
        Others = (ImageView) findViewById(R.id.others);
        saveItem = (Button) findViewById(R.id.save_item);
        mAuth = FirebaseAuth.getInstance();

        Calendar cal = Calendar.getInstance();
        String month = monthName[cal.get(Calendar.MONTH)];
        databaseExpenseTracker = FirebaseDatabase.getInstance().getReference(month).child(mAuth.getCurrentUser().getUid());

        //Define the button functionality
        Groceries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Groceries";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();
            }
        });
        Clothes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Clothes";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Electronic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Electronic";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Housing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Housing";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Leisure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Leisure";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Traveling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Traveling";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Transport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Transport";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Book";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Games.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Games";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Health";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Restaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Restaurant";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });
        Others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemId = "Others";
                Toast.makeText(ManualInputActivity.this,"You added " + editTextName.getText().toString() + " Kr for " + itemId, Toast.LENGTH_LONG).show();

            }
        });


        saveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveResult();
            }
        });


    }

    private void saveResult() {
        String mResult = editTextName.getText().toString();
        DateFormat df = new SimpleDateFormat("yyyyMMdd - hh:mm:ss");
        Date dateobj = new Date();
        String date = df.format(dateobj);
        if(!mAuth.getCurrentUser().getUid().isEmpty()) {
            if (!TextUtils.isEmpty(mResult)) {
                ExpenseTracker expensetracker = new ExpenseTracker(itemId, mResult, date);
                databaseExpenseTracker.child(itemId).child(date).setValue(expensetracker);
                Toast.makeText(ManualInputActivity.this, "Result added", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(ManualInputActivity.this, "You should choose the value or item category", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(this, "You should login first", Toast.LENGTH_LONG).show();
        }
    }
}
