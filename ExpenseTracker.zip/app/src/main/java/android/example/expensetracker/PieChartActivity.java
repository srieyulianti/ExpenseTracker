package android.example.expensetracker;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class PieChartActivity extends AppCompatActivity {
    DatabaseReference databaseExpenseTracker;
    FirebaseAuth mAuth;
    String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
            "October", "November", "December"};
    String Clothes;
    String Groceries;
    String Book;
    String Electronic;
    String Games;
    String Health;
    String Housing;
    String Leisure;
    String Others;
    String Restaurant;
    String Transport;
    String Traveling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pie_chart);

        mAuth = FirebaseAuth.getInstance();

        Calendar cal = Calendar.getInstance();
        String month = monthName[cal.get(Calendar.MONTH)];
        databaseExpenseTracker = FirebaseDatabase.getInstance().getReference(month).child(mAuth.getCurrentUser().getUid());
        databaseExpenseTracker.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                double totalAmount0 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Clothes").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount0 += Double.parseDouble(gettotalamount.getResult());
                }
                Clothes = Double.toString(totalAmount0);
                Double clothesExpense = totalAmount0;

                double totalAmount1 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Groceries").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount1 += Double.parseDouble(gettotalamount.getResult());
                }
                Groceries = Double.toString(totalAmount1);
                Double groceriesExpense = totalAmount1;

                double totalAmount2 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Book").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount2 += Double.parseDouble(gettotalamount.getResult());
                }
                Book = Double.toString(totalAmount2);
                Double bookExpense = totalAmount2;

                double totalAmount3 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Electronic").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount3 += Double.parseDouble(gettotalamount.getResult());
                }
                Electronic = Double.toString(totalAmount3);
                Double electronicExpense = totalAmount3;

                double totalAmount4 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Games").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount4 += Double.parseDouble(gettotalamount.getResult());
                }
                Games = Double.toString(totalAmount4);
                Double gamesExpense = totalAmount4;

                double totalAmount5 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Health").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount5 += Double.parseDouble(gettotalamount.getResult());
                }
                Health = Double.toString(totalAmount5);
                Double healthExpense = totalAmount5;

                double totalAmount6 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Housing").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount6 += Double.parseDouble(gettotalamount.getResult());
                }
                Housing = Double.toString(totalAmount6);
                Double housingExpense = totalAmount6;

                double totalAmount7 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Leisure").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount7 += Double.parseDouble(gettotalamount.getResult());
                }
                Leisure = Double.toString(totalAmount7);
                Double leisureExpense = totalAmount7;

                double totalAmount8 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Others").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount8 += Double.parseDouble(gettotalamount.getResult());
                }
                Others = Double.toString(totalAmount8);
                Double otherExpense = totalAmount8;

                double totalAmount9 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Restaurant").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount9 += Double.parseDouble(gettotalamount.getResult());
                }
                Restaurant = Double.toString(totalAmount9);
                Double restaurantExpense = totalAmount9;

                double totalAmount10 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Transport").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount10 += Double.parseDouble(gettotalamount.getResult());
                }
                Transport = Double.toString(totalAmount10);
                Double transportExpense = totalAmount10;

                double totalAmount11 = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.child("Traveling").getChildren()) {
                    GetTotalAmount gettotalamount = postSnapshot.getValue(GetTotalAmount.class);
                    totalAmount11 += Double.parseDouble(gettotalamount.getResult());
                }
                Traveling = Double.toString(totalAmount11);
                Double travelingExpense = totalAmount11;

                double expense[] = {clothesExpense, groceriesExpense, bookExpense, electronicExpense, gamesExpense, healthExpense,
                housingExpense, leisureExpense, otherExpense, restaurantExpense, transportExpense, travelingExpense};
                String item[]= {"Clothes", "Groceries", "Book", "Electronic", "Games", "Health", "Housing", "Leisure", "Others", "Restaurant", "Transport", "Traveling"};
                //Populating a list of PieEntries
                List<PieEntry> pieEntries = new ArrayList<>();
                for (int i = 0; i < expense.length; i++){
                    pieEntries.add(new PieEntry((float) expense[i], item[i]));
                }
                PieDataSet dataSet = new PieDataSet(pieEntries, "Statistic per Month");
                dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
                PieData data = new PieData(dataSet);

                //Get the chart
                PieChart chart = (PieChart) findViewById(R.id.chart);
                chart.setData(data);
                chart.animateY(1000);
                chart.setCenterText("Month Data");
                chart.setCenterTextSize(20);
                chart.setCenterTextRadiusPercent(70);
                chart.setCenterTextColor(Color.BLACK);
                chart.setHoleRadius(30);
                chart.setTransparentCircleRadius(40);
                chart.invalidate();


            }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Toast.makeText(PieChartActivity.this, "The read failed", Toast.LENGTH_LONG).show();
                }
            });
        }

}
