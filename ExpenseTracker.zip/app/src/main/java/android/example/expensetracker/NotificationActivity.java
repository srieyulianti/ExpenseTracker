package android.example.expensetracker;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class NotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        createNotificationChannel();

        Button button = (Button) findViewById(R.id.button);
        final TimePicker timer=(TimePicker)findViewById(R.id.timer);
        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"Reminder Set",Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(NotificationActivity.this,ReminderBroadcast.class);
                PendingIntent pendingIntent=PendingIntent.getBroadcast(NotificationActivity.this,0,intent,0);

                AlarmManager alarmManager= (AlarmManager) getSystemService(ALARM_SERVICE);

                int hour = timer.getHour();
                int minute = timer.getMinute();
                Calendar starttime = Calendar.getInstance();
                starttime.setTimeInMillis(System.currentTimeMillis());
                starttime.set(Calendar.HOUR_OF_DAY, hour);
                starttime.set(Calendar.MINUTE,minute);
                starttime.set(Calendar.SECOND,0);
                //long tenSecondsMilli =1000*10;
                alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,starttime.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);


            }
        });
    }

    private void createNotificationChannel() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name="LemubitReminderChannel";
            String description = "Channel for Lemubit Reminder";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel= new NotificationChannel("notifyLemubit",name, importance);
            channel.setDescription(description);


            NotificationManager notificationManager= getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);

        }
    }
}
