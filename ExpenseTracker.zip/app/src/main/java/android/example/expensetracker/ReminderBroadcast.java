package android.example.expensetracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderBroadcast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
//long[] v={0,1000};
        //Vibrator vibrator= (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
//        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        NotificationCompat.Builder builder= new NotificationCompat.Builder(context,"notifyLemubit").setSmallIcon(R.drawable.smalllogofinal)
                .setContentTitle("Expense Tracker").setContentText("Time to Update your Expenses").setPriority(NotificationCompat.PRIORITY_DEFAULT).setVibrate(new long[] {1000});

        NotificationManagerCompat notificationManager= NotificationManagerCompat.from(context);
//vibrator.vibrate(60);

        notificationManager.notify(200,builder.build());

        // builder.setSound(Uri.parse("uri://sadfasdfasdf.mp3"));
        //builder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);
    }
}
