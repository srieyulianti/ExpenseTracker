package android.example.expensetracker;

public class GetTotalAmount {
    private String date;
    private String itemId;
    private String result;

    public String getDate() {
        return date;
    }

    public String getItemId() {
        return itemId;
    }

    public String getResult() {
        return result;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
